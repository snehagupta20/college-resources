#include "HelloApp/Hello.hh"
class HelloImpl : public virtual POA_HelloApp::Hello {
public:char* sayHello() override {
return CORBA::string_
dup("Hello from C++ Server");
}
};
int main(int argc, char* argv[]) {
CORBA::ORB_var orb = CORBA::ORB_init(argc, argv);
PortableServer::POA_var poa = orb->resolve_initial_references("RootPOA");
PortableServer::POAManager_var manager = poa->the_POAManager();
HelloImpl hello_impl;
PortableServer::ServantBase_var servant = &hello_impl;
poa->activate_object(servant);
manager->activate();
orb->run();
return 0;
}