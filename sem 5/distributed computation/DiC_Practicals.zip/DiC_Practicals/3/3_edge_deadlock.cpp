#include<iostream>
#include<vector>
using namespace std;
int main()
{
int n, p1, s1, sp1, sp2;
cout<<"Enter total no. of sites: ";
cin>>n;
vector<int> p(n);
for (int i=0; i<n; i++)
{
cout<<"Enter total no. of process in S"<< i+1 << ": ";
cin>>p[i];
}
cout<<"Enter the site no. and process id for which deadlock detection should be initiated: ";
cin>>s1>>p1;
cout<<"Enter the processes of two different sites connected with requesting edge: ";
cin>>sp1>>sp2;
cout <<"Probe message is (" << p1 << "," << sp1 << "," << sp2 << ")" <<endl;
if (p1 == sp2)
cout << "Deadlock detected" << endl;
return 0;
}