#include <iostream>
#include <vector>
#include <thread>
#include <atomic>
#include <chrono>
using namespace std;
atomic<int> completedProcesses(0);
void process(int id)
{
    this_thread::sleep_for(chrono::milliseconds(1000));
    completedProcesses.fetch_add(1, memory_order_relaxed);
}
int main()
{
    int n;
    cout<<"Enter number of processes: ";
    cin>>n;
vector<thread> processes;
for (int i = 0; i < n; ++i)
processes.push_back(thread(process, i));
for (thread &t : processes)
t.join();
while (completedProcesses.load(memory_order_relaxed) < n)
{
this_thread::sleep_for(chrono::milliseconds(500));
cout << "Waiting for processes to complete..." << endl;
}
cout << "All processes have completed." << endl;
return 0;
}