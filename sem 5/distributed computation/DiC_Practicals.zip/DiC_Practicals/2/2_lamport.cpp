#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;
class Event {
public:
int timestamp;
string description;
Event(int t, string s)
{
timestamp = t;
description = s;
}
};
const bool eventCmp(const Event& a, const Event& b) {
return a.timestamp < b.timestamp;
}
int main() {
Event e1(2,
"A");
Event e2(1,
"B");
Event e3(4,
"C");
Event e4(3,
"D");
vector<Event> events = {e1,e2,e3,e4};
sort(events.begin(), events.end(), eventCmp);
cout << "Chronological Order of Events:" << endl;
for (Event event:events)
cout << "Timestamp " << event.timestamp << ": " << event.description << endl;
return 0;
}