#include <iostream>
#include <string>
using namespace std;
class RemoteService
{
public:
virtual int add(int a, int b) = 0;
};
class RemoteServiceImpl : public RemoteService
{
public:
int add(int a, int b) override
{
return a + b;
}
};
class RPCClient{
public:
int callRemoteAdd(int a, int b, RemoteService *service)
{
return service->add(a, b);
}
};
int main()
{
RemoteServiceImpl server;
RPCClient client;
int result = client.callRemoteAdd(5, 3, &server);
cout << "Result of the remote procedure call: " << result << endl;
return 0;
}