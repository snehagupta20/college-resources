#include <iostream>
#include <thread>
#include <mutex>
using namespace std;

mutex mtx;
void critical_section(int thread_id)
{
    mtx.lock();
    cout << "Thread " << thread_id << " is in the critical section." << endl;
    mtx.unlock();
}

int main()
{
    const int num_threads = 4;
    thread threads[num_threads];
    for (int i = 0; i < num_threads; ++i)
        threads[i] = thread(critical_section, i);
    for (int i = 0; i < num_threads; ++i)
        threads[i].join();
    return 0;
}