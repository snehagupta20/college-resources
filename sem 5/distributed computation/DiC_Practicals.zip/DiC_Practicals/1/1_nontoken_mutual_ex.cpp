#include<iostream>
#include<vector>
#include<map>
using namespace std;
int main()
{
    int ns,ncs,timestamp,site;
    cout<<"Enter number of sites: ";
    cin>>ns;
    cout<<"Enter number of sites which want to enter critical section: ";
    cin>>ncs;
    vector<int> ts(ns,0);
    vector<int> request;
    map<int,int> m;
    for(int i=0; i<ncs; i++)
    {
        cout<<endl<<"Enter timestamp "<<i+1<<": ";
        cin>>timestamp;
        cout<<"Enter site number: ";
        cin>>site;
        ts[site-1]=timestamp;
        request.push_back(site);
        m[timestamp]=site;
    }

    cout<<endl<<"Sites and Timestamp:"<<endl;

    for(int i=0;i<ts.size();i++)
     cout<<i+1<<" "<<ts[i]<<endl;
    for(int i=0; i<request.size(); i++)
    {
        cout<<endl<<"Request from site "<<request[i]<<":"<<endl;
        for(int j=0; j<ts.size(); j++)
        {
            if(request[i]!=j+1)
            {
                if((ts[j]>ts[request[i]-1])||(ts[j]==0))
                    cout<<j+1<<" Replied"<<endl;
                else
                    cout<<j+1<<" Deferred"<<endl;
            }
        }
    }
    cout<<endl;
    map<int,int>::iterator it;
    int c=0;
    for(it=m.begin(); it!=m.end(); it++)
    {
        cout<<"Site "<<it->second<<" entered Critical Section"<<endl;
        c++;
    }
    return 0;
}